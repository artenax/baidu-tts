#!/bin/bash
python3 /tmp/baidu/baidu.py
